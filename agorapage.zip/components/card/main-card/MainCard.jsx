/** @format */

import { HeartIcon, ImageSearchIcon, StarIcon } from "@/assets/svgIcons";
import Image from "next/image";
import React from "react";

const MainCard = () => {
  return (
    <div className='w-56 h-[400px] group'>
      <div className='w-56 h-[269px]  border border-neutral-200 rounded-lg cursor-pointer relative'>
        <Image
          src='/images/discounts/discount1.webp'
          alt='discount'
          objectFit='contain'
          layout='fill'
          className='w-full rounded-lg shadow-sm'
        />
        <div class='absolute bg-black/0 group-hover:bg-black/10 inset-0 transition-colors rounded-lg'></div>
      </div>
      <div className='flex justify-between items-center mt-3'>
        <h3 className='text-sm font-semibold text-black font-sans cursor-pointer hover:underline'>
          Aday
        </h3>
        <div className='rounded-xl hover:bg-neutral-100 p-1 cursor-pointer'>
          <HeartIcon className='text-gray-400 w-6 h-6' />
        </div>
      </div>
      <p className='text-sm text-gray-500 capitalize hover:underline font-sans mt-1 '>
        back to front shirt dress
      </p>
      <div className='flex justify-between items-center'>
        <div className='flex items-center my-3'>
          {Array.from({ length: 5 }, (_, index) => (
            <StarIcon
              key={index}
              className='w-4 h-4 text-black cursor-pointer'
            />
          ))}

          <div className='cursor-pointer px-2  bg-neutral-100 rounded-lg'>
            <span className='text-xs text-neutral-600 font-medium font-sans'>
              4.75
            </span>
          </div>
        </div>
        <div className='rounded-xl hover:bg-neutral-100 p-1'>
          <ImageSearchIcon className='w-6 h-6 text-gray-400 cursor-pointer' />
        </div>
      </div>
      <div className='flex'>
        <span className='text-sm cursor-pointer text-black font-semibold line-through mr-2'>
          $180.00
        </span>
        <span className='text-sm cursor-pointer text-black font-semibold'>
          $36.00
        </span>
      </div>
    </div>
  );
};

export default MainCard;

/** @format */

export const gift = [
  {
    imagePath: "/images/gift/gift1.png",
    title: "Gifts for mom",
  },
  {
    imagePath: "/images/gift/gift2.png",
    title: "Gifts for pet owners",
  },
  {
    imagePath: "/images/gift/gift3.png",
    title: "Gifts for dad",
  },
  {
    imagePath: "/images/gift/gift4.png",
    title: "Gifts for coworker",
  },
  {
    imagePath: "/images/gift/gift1.png",
    title: "Gifts for wife",
  },
  {
    imagePath: "/images/gift/gift1.png",
    title: "Gifts for friend",
  },
];

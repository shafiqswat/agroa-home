/** @format */

export const featuredCollection = [
  {
    firstImage: "/images/collections/collection1.jpg",
    secondImage: "/images/collections/collection2.png",
    thirdImage: "/images/collections/collection3.png",
    title: "Craft time",
  },
  {
    firstImage: "/images/collections/collection4.jpg",
    secondImage: "/images/collections/collection5.png",
    thirdImage: "/images/collections/collection6.png",
    title: "Christmas sweaters",
  },
  {
    firstImage: "/images/collections/collection7.png",
    secondImage: "/images/collections/collection8.png",
    thirdImage: "/images/collections/collection9.png",
    title: "Cream time",
  },
  {
    firstImage: "/images/collections/collection1.jpg",
    secondImage: "/images/collections/collection2.png",
    thirdImage: "/images/collections/collection3.png",
    title: "Craft time",
  },
  {
    firstImage: "/images/collections/collection4.jpg",
    secondImage: "/images/collections/collection5.png",
    thirdImage: "/images/collections/collection6.png",
    title: "Christmas sweaters",
  },
  {
    firstImage: "/images/collections/collection7.png",
    secondImage: "/images/collections/collection8.png",
    thirdImage: "/images/collections/collection9.png",
    title: "Cream time",
  },
];

/** @format */

export const store = [
  {
    title: "DOG Pets",
    firstImage: "/images/stores/store1.png",
    secondImage: "/images/stores/store2.png",
    thirdImage: "/images/stores/store3.png",
    lastImage: "/images/stores/store4.png",
  },
  {
    title: "Eouaker",
    firstImage: "/images/stores/store5.png",
    secondImage: "/images/stores/store6.png",
    thirdImage: "/images/stores/store7.png",
    lastImage: "/images/stores/store8.png",
  },
  {
    title: "Calzuro",
    firstImage: "/images/stores/store9.png",
    secondImage: "/images/stores/store10.png",
    thirdImage: "/images/stores/store11.png",
    lastImage: "/images/stores/store12.png",
  },
  {
    title: "DOG Pets",
    firstImage: "/images/stores/store1.png",
    secondImage: "/images/stores/store2.png",
    thirdImage: "/images/stores/store3.png",
    lastImage: "/images/stores/store4.png",
  },
  {
    title: "Eouaker",
    firstImage: "/images/stores/store5.png",
    secondImage: "/images/stores/store6.png",
    thirdImage: "/images/stores/store7.png",
    lastImage: "/images/stores/store8.png",
  },
  {
    title: "Calzuro",
    firstImage: "/images/stores/store9.png",
    secondImage: "/images/stores/store10.png",
    thirdImage: "/images/stores/store11.png",
    lastImage: "/images/stores/store12.png",
  },
];
